from tkinter import *
import DataTransmissionLayer
from tkinter import messagebox as msg

class NewDamageEvent:
    def LoadRegisterNewDamageEvent(self):
        newDamageForm = Tk()
        newDamageForm.title("New Damage Event")
        newDamageForm.geometry('500x600')
        newDamageForm.resizable(0, 0)

        txtProjectID=StringVar()
        txtInsuranceCompanyID = StringVar()
        txtInsuranceValue = StringVar()
        txtDisasterDate = StringVar()
        txtEvaluatorCompanyID = StringVar()
        txtValueOfDamagePredicted = StringVar()
        txtValueOFDamageReal = StringVar()

        def BackMethod():
            from .MainForm import MainFormClass
            newForm = MainFormClass()
            newDamageForm.destroy()
            newForm.LoadMainForm()
        def SetNewInsuranceUpdate():
            connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)
            msg.showinfo('Done', 'The new event is added sucessfully!')
            sqlCommand = connection.cursor()
            quarry = 'INSERT INTO [dbo].[DamageEvaluationEvent] ([ProjectNameID],[InsuranceCompanyID],[InsuranceValue],[DisasterDate],[EvaluatorCompanyID],[ValueOfDamagePredicted],[ValueOfDamageReal])values(?,?,?,?,?,?,?)'
            sqlCommand.execute(quarry, (
            txtProjectID.get(), txtInsuranceCompanyID.get(), txtInsuranceValue.get(), txtDisasterDate.get(),
            txtEvaluatorCompanyID.get(),txtValueOfDamagePredicted.get(), txtValueOFDamageReal.get()))
            sqlCommand.commit()
            for widget in frame1.winfo_children():
                if isinstance(widget, Entry):
                    widget.delete(0, END)


        frame1 = LabelFrame(newDamageForm)

        lblProjectID = Label(frame1, text='Project ID:', font=('calibary',12))
        lblProjectID.grid(row=0, column=0, pady=10, padx=10)

        lblInsuranceCompanyID = Label(frame1, text='Insurance Company ID:', font=('calibary', 12))
        lblInsuranceCompanyID.grid(row=1, column=0, pady=10, padx=10)

        lblInsuranceValue = Label(frame1, text='Insurance Value:', font=('calibary', 12))
        lblInsuranceValue.grid(row=2, column=0, pady=10, padx=10)

        lblDisasterDate = Label(frame1, text='Disaster Date:', font=('calibary', 12))
        lblDisasterDate.grid(row=3, column=0, pady=10, padx=10)

        lblEvaluatorCompanyID = Label(frame1, text='Evaluator Company ID:', font=('calibary', 12))
        lblEvaluatorCompanyID.grid(row=4, column=0, pady=10, padx=10)

        lblValueOfDamagePredicted = Label(frame1, text='Value Of Damage Predicted:', font=('calibary', 12))
        lblValueOfDamagePredicted.grid(row=5, column=0, pady=10, padx=10)

        lblValueOfDamageReal = Label(frame1, text='Value Of Damage Real:', font=('calibary', 12))
        lblValueOfDamageReal.grid(row=6, column=0, pady=10, padx=10)

        entProjectID = Entry(frame1, width=30, textvariable= txtProjectID)
        entProjectID.grid(row=0, column=1, padx=10, pady=10)

        entInsuranceCompanyID = Entry(frame1, width=30, textvariable=txtInsuranceCompanyID)
        entInsuranceCompanyID.grid(row=1, column=1, padx=10, pady=10)

        entInsuranceValue = Entry(frame1, width=30, textvariable=txtInsuranceValue)
        entInsuranceValue.grid(row=2, column=1, padx=10, pady=10)

        entDisasterDate = Entry(frame1, width=30, textvariable=txtDisasterDate)
        entDisasterDate.grid(row=3, column=1, padx=10, pady=10)

        entEvaluatorCompanyID = Entry(frame1, width=30, textvariable=txtEvaluatorCompanyID)
        entEvaluatorCompanyID.grid(row=4, column=1, padx=10, pady=10)

        entValueOfDamagePredicted = Entry(frame1, width=30, textvariable=txtValueOfDamagePredicted)
        entValueOfDamagePredicted.grid(row=5, column=1, padx=10, pady=10)

        entValueOfDamageReal = Entry(frame1, width=30, textvariable=txtValueOFDamageReal)
        entValueOfDamageReal.grid(row=6, column=1, padx=10, pady=10)

        btnBack = Button(frame1, text='Back', command=BackMethod, width=10)
        btnBack.grid(row=7, column=1, padx=10, pady=10, sticky='wn')

        btnSet = Button(frame1, text='Set', width=10, command=SetNewInsuranceUpdate)
        btnSet.grid(row=7, column=1, padx=10, pady=10, sticky='en')

        frame1.place(x=10, y=10)

        image2= PhotoImage(file='149.png')
        frame2= Frame(newDamageForm)

        picbtn2 = Label(master=frame2, image=image2)

        picbtn2.grid(row=0, column=0, padx=15, ipadx=15)
        frame2.place(x=100, y=390)



        newDamageForm.mainloop()
