from tkinter import *
from tkinter import messagebox as msg
from DataTransmissionLayer import *
import DataTransmissionLayer

class NewEvaluationCompany:
    def LoadRegisterEvaluatioCompany(self):
        newEvaluationCompanyForm = Tk()
        newEvaluationCompanyForm.title("New Evaluation Company")
        newEvaluationCompanyForm.geometry('480x500')
        newEvaluationCompanyForm.resizable(0, 0)


        def BackMethod():
            from .MainForm import MainFormClass
            newForm = MainFormClass()
            newEvaluationCompanyForm.destroy()
            newForm.LoadMainForm()
        def SetNewEvaluationCompany():
            connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)
            msg.showinfo('Done', 'The company is added sucessfully!')
            sqlCommand = connection.cursor()
            quarry = 'INSERT INTO [dbo].[EvaluationCompanies]([CompanyName],[TelNumber],[FaxNumber],[Address],[ManagerName],[EstablishmentDate]) values(?,?,?,?,?,?)'
            sqlCommand.execute(quarry, (txtEvaluationCompanyName.get(), txtTellNumber.get(), txtFaxNumber.get(),txtManagerName.get(), txtAddress.get(),txtEstablishmentDate.get()))
            sqlCommand.commit()
            for widget in frame1.winfo_children():
                if isinstance(widget,Entry):
                    widget.delete(0,END)


        txtEvaluationCompanyName= StringVar()
        txtTellNumber = StringVar()
        txtFaxNumber = StringVar()
        txtAddress = StringVar()
        txtManagerName= StringVar()
        txtEstablishmentDate = StringVar()


        frame1 = LabelFrame(newEvaluationCompanyForm, padx=20, pady = 10)

        lblEvaluationCompanyName = Label(frame1, text = 'Evaluation Company Name', font=('calibary', 12) )
        lblEvaluationCompanyName.grid(row=0, column=0, pady=10, padx=10)

        lblTelNumber = Label(frame1, text='Tell Number', font=('calibary', 12))
        lblTelNumber.grid(row=1, column=0, pady=10, padx=10)

        lblFaxNumber = Label(frame1, text='Fax Number', font=('calibary', 12))
        lblFaxNumber.grid(row=2, column=0, pady=10, padx=10)

        lblAddress = Label(frame1, text='Address', font=('calibary', 12))
        lblAddress.grid(row=3, column=0, pady=10, padx=10)

        lblManagerName = Label(frame1, text='Manager Name', font=('calibary', 12))
        lblManagerName.grid(row=4, column=0, pady=10, padx=10)

        lblEstablishmentDate = Label(frame1, text='Establishment Date', font=('calibary', 12))
        lblEstablishmentDate.grid(row=5, column=0, pady=10, padx=10)

        entEvaluationCompanyName = Entry(frame1, width=25, textvariable=txtEvaluationCompanyName)
        entEvaluationCompanyName.grid(row=0, column=1, padx=10, pady=10)

        entTellNumber = Entry(frame1, width=25, textvariable=txtTellNumber)
        entTellNumber.grid(row=1, column=1, padx=10, pady=10)

        entFaxNumber = Entry(frame1, width=25, textvariable=txtFaxNumber)
        entFaxNumber.grid(row=2, column=1, padx=10, pady=10)

        entAddress = Entry(frame1, width=25, textvariable=txtAddress)
        entAddress.grid(row=3, column=1, padx=10, pady=10)

        entManagerName = Entry(frame1, width=25, textvariable=txtManagerName)
        entManagerName.grid(row=4, column=1, padx=10, pady=10)

        entEstablishmentDate = Entry(frame1, width=25, textvariable=txtEstablishmentDate)
        entEstablishmentDate.grid(row=5, column=1, padx=10, pady=10)

        btnBack= Button(frame1, text= 'Back', width=12, command=BackMethod)
        btnBack.grid(row=6, column=1, sticky='w')

        btnSet = Button(frame1, text='Set', width=12 ,command= SetNewEvaluationCompany)
        btnSet.grid(row=6, column=1, sticky='e')

        frame1.place(x=10, y=10)

        image2= PhotoImage(file='147.png')
        frame2= Frame(newEvaluationCompanyForm)

        picbtn2 = Label(master=frame2, image=image2)

        picbtn2.grid(row=0, column=0, padx=15, ipadx=15)
        frame2.place(x=30, y=350)



        newEvaluationCompanyForm.mainloop()
