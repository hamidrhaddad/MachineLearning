from tkinter import *
from tkinter import messagebox as msg
import DataTransmissionLayer
from tkinter import ttk
from .MainForm import *
from DataTransmissionLayer import *


class NewEmployee:
    def LoadRegisterUser(self):
        newEmployeeForm = Tk()
        newEmployeeForm.title("New Employee")
        newEmployeeForm.geometry('450x620')
        newEmployeeForm.resizable(0, 0)



        txtFirstName = StringVar()
        txtLastName= StringVar()
        txtHireDate = StringVar()
        txtBirthDate = StringVar()
        txtNationalCode = StringVar()
        txtCellPhone = StringVar()
        txtEmail = StringVar()
        txtDepartmentID = StringVar()


        def BackMethod():
            from .MainForm import MainFormClass
            newForm = MainFormClass()
            newEmployeeForm.destroy()
            newForm.LoadMainForm()
        def SetEmpMethod():
            bb= entDepartmentID.current() + 1

            connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)
            msg.showinfo('Done','The user is added sucessfully!')
            sqlCommand = connection.cursor()
            quarry = 'INSERT INTO [dbo].[IWPCOContractTeam]([FirstName],[LastName],[HireDate] ,[BirthDate],[NationalCode],[Mobile],[EmailAddress],[DepartmentTypeID])values (?,?,?,?,?,?,?,?)'
            sqlCommand.execute(quarry,(txtFirstName.get(),txtLastName.get(),txtHireDate.get(),txtBirthDate.get(),txtNationalCode.get(),txtCellPhone.get(),txtEmail.get(),bb))
            sqlCommand.commit()
            for widget in fram1.winfo_children():
                if isinstance(widget,Entry):
                    widget.delete(0,END)





        fram1= LabelFrame(newEmployeeForm)
        lblFirstName = Label(master=fram1, text= 'First Name', font= ('calibary',12))
        lblFirstName.grid(row=0, column=0, pady=10, padx=10)

        lblLasttName = Label(master=fram1, text='Last Name', font=('calibary', 12))
        lblLasttName.grid(row=1, column=0, pady=10, padx=10)

        lblHireDate = Label(master=fram1, text='Hire Date', font=('calibary', 12))
        lblHireDate.grid(row=2, column=0, pady=10, padx=10)

        lblBirthDate = Label(master=fram1, text='Birth Date', font=('calibary', 12))
        lblBirthDate.grid(row=3, column=0, pady=10, padx=10)

        lblNationalCode = Label(master=fram1, text='National Code', font=('calibary', 12))
        lblNationalCode.grid(row=4, column=0, pady=10, padx=10)

        lblCellPhone = Label(master=fram1, text='Cell Phone', font=('calibary', 12))
        lblCellPhone.grid(row=5, column=0, pady=10, padx=10)

        lblEmail = Label(master=fram1, text='Emai Address', font=('calibary', 12))
        lblEmail.grid(row=6, column=0, pady=10, padx=10)

        lblDepartmentID = Label(master=fram1, text='Department ID', font=('calibary', 12))
        lblDepartmentID.grid(row=7, column=0, pady=10, padx=10)

        entFirstName = Entry(fram1, width=30, textvariable= txtFirstName)
        entFirstName.grid(row=0, column=1, padx=10, pady=10)


        entLastName = Entry(fram1, width=30, textvariable= txtLastName)
        entLastName.grid(row=1, column=1, padx=10, pady=10)


        entHireDate = Entry(fram1, width=30, textvariable= txtHireDate)
        entHireDate.grid(row=2, column=1, padx=10, pady=10)


        entBirthDate = Entry(fram1, width=30, textvariable= txtBirthDate)
        entBirthDate.grid(row=3, column=1, padx=10, pady=10)


        entNationalCode = Entry(fram1, width=30, textvariable= txtNationalCode)
        entNationalCode.grid(row=4, column=1, padx=10, pady=10)


        entCelPhone = Entry(fram1, width=30, textvariable= txtCellPhone)
        entCelPhone.grid(row=5, column=1, padx=10, pady=10)


        entEmailAddress = Entry(fram1, width=30, textvariable= txtEmail)
        entEmailAddress.grid(row=6, column=1, padx=10, pady=10)

        connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)
        sqlCommand = connection.cursor()
        quarry = 'select departmentTitle from [dbo].[DepartmentType]'
        sqlCommand.execute(quarry)
        aa = sqlCommand.fetchall()




        entDepartmentID = ttk.Combobox(fram1, width=28 , height=1, textvariable=txtDepartmentID)
        entDepartmentID['values']= aa
        entDepartmentID.grid(row=7, column=1, padx=10, pady=10)


        btnBack = Button(fram1, text='Back', width=12, command= BackMethod)
        btnBack.grid(row=8, column=1, sticky='w')

        btnSet = Button(fram1, text='Set Employee', width=12, command=SetEmpMethod)
        btnSet.grid(row=8, column=1, sticky='e')

        fram1.place(x=10, y=10)

        image2 = PhotoImage(file='133.png')

        frame2 = Frame(newEmployeeForm)
        picbtn = Label(master=frame2, image=image2)

        picbtn.grid(row=0, column=0, padx=15, ipadx=15, sticky='we')
        frame2.place(x=100, y=410)

        newEmployeeForm.mainloop()
