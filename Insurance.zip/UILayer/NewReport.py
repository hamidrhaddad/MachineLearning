from tkinter import *
from tkinter import messagebox as msg
from tkinter import ttk
import DataTransmissionLayer
class NewReport:
    def LoadNewReport(self):
        newReportForm = Tk()
        newReportForm.title("New Report")
        newReportForm.geometry('420x520')
        newReportForm.resizable(0, 0)

        fram1= Frame(newReportForm)

        txtCompanyName = StringVar()
        txtReport1=StringVar()

        def BackMethod():
            from .MainForm import MainFormClass
            newForm = MainFormClass()
            newReportForm.destroy()
            newForm.LoadMainForm()
        def GetNewReport():

            connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)

            sqlCommand = connection.cursor()
            quarry = "select sum(f.InsuranceValue) from dbo.InsuranceCompanies as t inner join dbo.InsuranceIssuing as f  on t.id = f.CompanyId where t.EnglishCompanyName = ?"
            bb = txtCompanyName.get()
            sqlCommand.execute(quarry, bb)
            result = sqlCommand.fetchone()[0]
            txtReport1.set((result))


        lblCompanyName = Label(fram1, text='Company Name to English', font=('calibary', 12))
        lblCompanyName.grid(row=0, column=0, padx=10, pady=10)

        lblResultValue = Label(fram1, text='Result Value', font=('calibary', 12))
        lblResultValue.grid(row=1, column=0, padx=10, pady=10)

        entCompanyName = Entry(fram1, width=25, textvariable=txtCompanyName)
        entCompanyName.grid(row=0, column=1, pady=10, padx=10)

        entResult = Entry(fram1, width=25, textvariable=txtReport1)
        entResult.grid(row=1, column=1, pady=10, padx=10)

        btnBack = Button(fram1, text='Back', width=12, command=BackMethod)
        btnBack.grid(row=2, column=1, sticky='w')

        btnShowResult = Button(fram1, text='Result', width=12, command =GetNewReport )
        btnShowResult.grid(row=2, column=1, sticky='e')

        fram1.place(x=0, y=0)

        image2= PhotoImage(file='145.png')
        frame2= Frame(newReportForm)

        picbtn2 = Label(master=frame2, image=image2)

        picbtn2.grid(row=0, column=0, padx=15, ipadx=15)
        frame2.place(x=50, y=320)

        newReportForm.mainloop()


