import DataTransmissionLayer
from tkinter import *
from tkinter import ttk
from tkinter import messagebox as msg

class NewInsuranceCompany:
    def LoadRegisterInsuranceCompany(self):
        newInsuranceCompanyForm = Tk()
        newInsuranceCompanyForm.title("New Insurance Company")
        newInsuranceCompanyForm.geometry('500x600')
        newInsuranceCompanyForm.resizable(0, 0)
        def BackMethod():
            from .MainForm import MainFormClass
            newForm = MainFormClass()
            newInsuranceCompanyForm.destroy()
            newForm.LoadMainForm()
        def SetNewInsuranceCompany():
            bb = entInsuranceTypeID.current()+1
            connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)
            msg.showinfo('Done', 'The company is added sucessfully!')
            sqlCommand = connection.cursor()
            quarry = 'INSERT INTO [dbo].[InsuranceCompanies] ([ComapnayName],[TelNumber],[FaxNaumber],[Address],[ManagerName],[EstablishmentDate],[InsuranceTypeCompanyId], [EnglishCompanyName]) values(?,?,?,?,?,?,?,?)'
            sqlCommand.execute(quarry, (
            txtCompanyName.get(),txtNumber.get(), txtFaxNumber.get(), txtAddress.get(), txtManagerName.get(),
            txtEstablishmentDate.get(), bb, txtEnglishCompanyName.get()))
            sqlCommand.commit()
            for widget in frame1.winfo_children():
                if isinstance(widget,Entry):
                    widget.delete(0,END)



        txtCompanyName = StringVar()
        txtEnglishCompanyName = StringVar()
        txtNumber = StringVar()
        txtFaxNumber = StringVar()
        txtAddress = StringVar()
        txtManagerName = StringVar()
        txtEstablishmentDate = StringVar()
        txtInsuranceID = StringVar()


        frame1 = Frame(newInsuranceCompanyForm)
        lblCompanyName = Label(frame1, text = 'Company Name:', font = ('calibary',12))
        lblCompanyName.grid(row=0, column=0 , pady=10, padx=10)

        lblNumber = Label(frame1, text='Number:', font=('calibary', 12))
        lblNumber.grid(row=1, column=0, pady=10, padx=10)

        lblFaxNumber = Label(frame1, text='Fax Number:', font=('calibary', 12))
        lblFaxNumber.grid(row=2, column=0, pady=10, padx=10)

        lblAddress = Label(frame1, text='Address:', font=('calibary', 12))
        lblAddress.grid(row=3, column=0, pady=10, padx=10)

        lblManagerName = Label(frame1, text='Manager Name:', font=('calibary', 12))
        lblManagerName.grid(row=4, column=0, pady=10, padx=10)

        lblEstablihmentDate = Label(frame1, text='Establishment Date:', font=('calibary', 12))
        lblEstablihmentDate.grid(row=5, column=0, pady=10, padx=10)

        lblInsuranceTypeID = Label(frame1, text='Insurance Type ID:', font=('calibary', 12))
        lblInsuranceTypeID.grid(row=6, column=0, pady=10, padx=10)

        lblEnglishTitle = Label(frame1, text='English Company title:', font=('calibary', 12))
        lblEnglishTitle.grid(row=7, column=0, pady=10, padx=10)

        entCompanyName = Entry(frame1, width=35, textvariable = txtCompanyName )
        entCompanyName.grid(row=0, column=1, padx=10, pady=10)

        entNumber = Entry(frame1, width=35, textvariable=txtNumber)
        entNumber.grid(row=1, column=1, padx=10, pady=10)

        entFaxNumber = Entry(frame1, width=35, textvariable=txtFaxNumber)
        entFaxNumber.grid(row=2, column=1, padx=10, pady=10)

        entAddress = Entry(frame1, width=35, textvariable=txtAddress)
        entAddress.grid(row=3, column=1, padx=10, pady=10)

        entManagerName = Entry(frame1, width=35, textvariable=txtManagerName)
        entManagerName.grid(row=4, column=1, padx=10, pady=10)

        entEstablishmentDate = Entry(frame1, width=35, textvariable=txtEstablishmentDate)
        entEstablishmentDate.grid(row=5, column=1, padx=10, pady=10)

        connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)
        sqlCommand = connection.cursor()
        quarry = 'select InsuranceTypeTitle from [dbo].[InsuranceType]'
        sqlCommand.execute(quarry)
        aa = sqlCommand.fetchall()

        entInsuranceTypeID = ttk.Combobox(frame1, width=32, height=1, textvariable=txtInsuranceID)
        entInsuranceTypeID.grid(row=6, column=1, padx=10, pady=10)
        entInsuranceTypeID['values']=aa

        entEnglishTitle = Entry(frame1, width=35, textvariable=txtEnglishCompanyName)
        entEnglishTitle.grid(row=7, column=1, padx=10, pady=10)

        btnBack = Button(frame1, text='Back', width=15, command=BackMethod)
        btnBack.grid(row=8, column=1, sticky='wn')

        btnSet = Button(frame1, text='Set', width=15, command=SetNewInsuranceCompany)
        btnSet.grid(row=8, column=1, sticky='en')


        frame1.place(x=0, y=0)

        image2 = PhotoImage(file='148.png')
        frame2 = Frame(newInsuranceCompanyForm)

        picbtn2 = Label(master=frame2, image=image2)

        picbtn2.grid(row=0, column=0, padx=15, ipadx=15)

        frame2.place(x=130, y=390)

        newInsuranceCompanyForm.mainloop()
