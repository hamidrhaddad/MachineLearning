from tkinter import *

from .NewEmployee import *
from .NewProject import *
from .NewEvaluationCompany import *
from .NewInsuranceCompany import *
from .NewInsurance import *
from .NewDamageEvent import *
from .NewReport import *


class MainFormClass:
    def LoadMainForm(self):
        mainForm = Tk()
        mainForm.title("Main Form")
        mainForm.geometry('600x500')
        mainForm.resizable(0, 0)


        def RegisterNewUserMethod():
            newEmployeeForm = NewEmployee()
            mainForm.destroy()
            newEmployeeForm.LoadRegisterUser()
        def RegisterNewProjectMethod():
            newProjectForm = NewProject()
            mainForm.destroy()
            newProjectForm.LoadRegisterProject()
        def RegisterNewEvaluationCompanyMethod():
            newEvaluationForm = NewEvaluationCompany()
            mainForm.destroy()
            newEvaluationForm.LoadRegisterEvaluatioCompany()
        def RegisterNewInsuranceCompanyMethod():
            newInsuranceCompanyForm =NewInsuranceCompany ()
            mainForm.destroy()
            newInsuranceCompanyForm.LoadRegisterInsuranceCompany()
        def RegisterNewInsuranceMethod():
            newInsurance = NewInsurance()
            mainForm.destroy()
            newInsurance.LoadRegisterInsurance()
        def RegisterNewDamageEventMethod():
            newdamage = NewDamageEvent()
            mainForm.destroy()
            newdamage.LoadRegisterNewDamageEvent()
        def RegisterNewReport():
            newreportForm = NewReport()
            mainForm.destroy()
            newreportForm.LoadNewReport()


        mainFrame = LabelFrame(mainForm, bg='white')

        btnEmployeeRegister = Button( master=mainFrame, text= 'Register Employee', width=25 , command= RegisterNewUserMethod )
        btnEmployeeRegister.grid(row=0, column=0, padx=10, pady=10)

        btnProjectRegister = Button(master=mainFrame, text= 'Register Project' , width=25 , command= RegisterNewProjectMethod )
        btnProjectRegister.grid(row=1, column=0, padx= 10, pady=10)

        btnEvaluationCompanyRegister = Button(master=mainFrame, text= 'Register Evaluation Company' , width=25, command=RegisterNewEvaluationCompanyMethod )
        btnEvaluationCompanyRegister.grid(row=2, column=0, padx= 10, pady=10)

        btnInsuranceCompanyRegister = Button(master=mainFrame, text='Register Insurance Company', width=25, command= RegisterNewInsuranceCompanyMethod)
        btnInsuranceCompanyRegister.grid(row=3, column=0, padx=10, pady=10)

        btnNewInsurance = Button(master=mainFrame, text='Register New Insurance', width=25, command=RegisterNewInsuranceMethod)
        btnNewInsurance.grid(row=4, column=0, padx=10, pady=10)

        btnNewEvent = Button(master=mainFrame, text='Register Damage Event', width=25, command = RegisterNewDamageEventMethod)
        btnNewEvent.grid(row=5, column=0, padx=10, pady=10)
        mainFrame.place(x=10, y=10)

        btnNewReport = Button(master=mainFrame, text='New Report', width=25, command=RegisterNewReport)
        btnNewReport.grid(row=6, column=0, padx=10, pady=10)
        mainFrame.place(x=10, y=10)

        image2 = PhotoImage(file='123.png')

        frame2 = Frame(mainForm)
        picbtn = Label( frame2, image = image2 )

        picbtn.grid(row=0, column=0, padx=15, ipadx=15)
        frame2.place(x=230, y=30)


        image3 = PhotoImage(file='124.png')

        frame3 = Frame(mainForm)
        picbtn2 = Label(master= frame3, image = image3 )

        picbtn2.grid(row=0, column=0, padx=15, ipadx=15)
        frame3.place(x=220, y=300)

        mainForm.mainloop()

