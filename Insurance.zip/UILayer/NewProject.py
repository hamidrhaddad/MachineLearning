from tkinter import *
from tkinter import messagebox as msg
from tkinter import ttk
import DataTransmissionLayer
class NewProject:
    def LoadRegisterProject(self):
        newProjectForm = Tk()
        newProjectForm.title("New Project")
        newProjectForm.geometry('400x520')
        newProjectForm.resizable(0, 0)

        fram1= Frame(newProjectForm)

        txtProjectName = StringVar()
        txtStartDate=StringVar()
        txtLocation= StringVar()
        txtPriority=StringVar()
        txtProjectTypeID=StringVar()
        txtProjectManager= StringVar()


        def BackMethod():
            from .MainForm import MainFormClass
            newForm = MainFormClass()
            newProjectForm.destroy()
            newForm.LoadMainForm()
        def SetNewProject():
            bb = entProjectTypeID.current() + 1
            connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)
            msg.showinfo('Done', 'The project is added sucessfully!')
            sqlCommand = connection.cursor()
            quarry = 'INSERT INTO [dbo].[Projects] ([ProjectName],[StartDate],[Location],[priority],[ProjectTypeID],[ProjectManager])values(?,?,?,?,?,?)'
            sqlCommand.execute(quarry, (
                txtProjectName.get(), txtStartDate.get(), txtLocation.get(), txtPriority.get(), bb,
                txtProjectManager.get()))
            sqlCommand.commit()
            for widget in fram1.winfo_children():
                if isinstance(widget, Entry):
                    widget.delete(0, END)

        lblProjectName = Label(fram1, text='Project Name', font=('calibary', 12))
        lblProjectName.grid(row=0, column=0, padx=10, pady=10)

        lblStartDate = Label(fram1, text='Start Date', font=('calibary', 12))
        lblStartDate.grid(row=1, column=0, padx=10, pady=10)

        lblLocation = Label(fram1, text='Location', font=('calibary', 12))
        lblLocation.grid(row=2, column=0, padx=10, pady=10)

        lblProjectPriority = Label(fram1, text='Project Priority', font=('calibary', 12))
        lblProjectPriority.grid(row=3, column=0, padx=10, pady=10)

        lblProjectTypeId = Label(fram1, text='Project Type ID', font=('calibary', 12))
        lblProjectTypeId.grid(row=4, column=0, padx=10, pady=10)

        lblProjectManager = Label(fram1, text='Project Manager', font=('calibary', 12))
        lblProjectManager.grid(row=5, column=0, padx=10, pady=10)

        entProjectName = Entry(fram1, width=25, textvariable=txtProjectName)
        entProjectName.grid(row=0, column=1, pady=10, padx=10)

        entStartDate = Entry(fram1, width=25, textvariable=txtStartDate)
        entStartDate.grid(row=1, column=1, pady=10, padx=10)

        entLocation = Entry(fram1, width=25, textvariable=txtLocation)
        entLocation.grid(row=2, column=1, pady=10, padx=10)

        entPriority = ttk.Combobox(fram1, width=22, height=1, textvariable=txtPriority)
        aa= list(range(1,6,1))
        entPriority['values']=aa
        entPriority.grid(row=3, column=1, pady=10, padx=10)

        connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)
        sqlCommand = connection.cursor()
        quarry = 'select ProjectTypeTitle from [dbo].[ProjectType]'
        sqlCommand.execute(quarry)
        aa = sqlCommand.fetchall()
        entProjectTypeID = ttk.Combobox(fram1, width=22, textvariable=txtProjectTypeID)
        entProjectTypeID.grid(row=4, column=1, pady=10, padx=10)
        entProjectTypeID['values']=aa

        entProjectManager = Entry(fram1, width=25, textvariable=txtProjectManager)
        entProjectManager.grid(row=5, column=1, pady=10, padx=10)

        btnBack = Button(fram1, text='Back', width=12, command=BackMethod)
        btnBack.grid(row=6, column=1, sticky='w')

        btnSet = Button(fram1, text='Set', width=12, command=SetNewProject)
        btnSet.grid(row=6, column=1, sticky='e')

        fram1.place(x=0, y=0)

        image2= PhotoImage(file='145.png')
        frame2= Frame(newProjectForm)

        picbtn2 = Label(master=frame2, image=image2)

        picbtn2.grid(row=0, column=0, padx=15, ipadx=15)
        frame2.place(x=50, y=320)

        newProjectForm.mainloop()


