import DataTransmissionLayer
from tkinter import *
from tkinter import ttk
from tkinter import messagebox as msg

class NewInsurance:
    def LoadRegisterInsurance(self):
        newInsurance = Tk()
        newInsurance.title("Adding New Insurance")
        newInsurance.geometry('500x600')
        newInsurance.resizable(0, 0)


        def BackMethod():
            from .MainForm import MainFormClass
            newForm = MainFormClass()
            newInsurance.destroy()
            newForm.LoadMainForm()
        def SetNewInsurance():


            connection = DataTransmissionLayer.NewConnectionString.MainNewConnctionString(self)
            msg.showinfo('Done', 'The new insurance is added sucessfully!')
            sqlCommand = connection.cursor()
            quarry = 'INSERT INTO [dbo].[InsuranceIssuing]([CompanyId],[ProjectId],[InsuranceTypeId],[InsuranceValue],[DateofIssuing],[NumberOfInstallments],[PersonId]) values(?,?,?,?,?,?,?)'
            sqlCommand.execute(quarry, (
            txtCompanyID.get(), txtProjectID.get(), txtInsuranceTypeID.get(), txtInsuranceValue.get(),
            txtDateOfIssuing.get(),txtNumberOfInatallments.get(), txtPerosonID.get()))
            sqlCommand.commit()
            for widget in frame1.winfo_children():
                if isinstance(widget, Entry):
                    widget.delete(0, END)

        txtCompanyID = StringVar()
        txtProjectID = StringVar()
        txtInsuranceTypeID = StringVar()
        txtInsuranceValue = StringVar()
        txtDateOfIssuing = StringVar()
        txtNumberOfInatallments= StringVar()
        txtPerosonID = StringVar()



        frame1 = Frame(newInsurance)

        lblCompanyID = Label(frame1, text='Company ID:', font=('calibary',12))
        lblCompanyID.grid(row=0, column=0, padx=10, pady=10)

        lblProjecID = Label(frame1, text='Project ID:', font=('calibary', 12))
        lblProjecID.grid(row=1, column=0, padx=10, pady=10)

        lblInsuranceTypeID = Label(frame1, text='Type ID:', font=('calibary', 12))
        lblInsuranceTypeID.grid(row=2, column=0, padx=10, pady=10)

        lblInsuranceValue = Label(frame1, text='Insurance Value:', font=('calibary', 12))
        lblInsuranceValue.grid(row=3, column=0, padx=10, pady=10)

        lblDateOfIssuing = Label(frame1, text='Date of Issue:', font=('calibary', 12))
        lblDateOfIssuing.grid(row=4, column=0, padx=10, pady=10)

        lblNumberOfInstallments = Label(frame1, text='Number Of Installments:', font=('calibary', 12))
        lblNumberOfInstallments.grid(row=5, column=0, padx=10, pady=10)

        lblPersonID = Label(frame1, text='Person ID:', font=('calibary', 12))
        lblPersonID.grid(row=6, column=0, padx=10, pady=10)

        entCompanyID = Entry(frame1, textvariable=txtCompanyID, width=30)
        entCompanyID.grid(row= 0, column=1, pady=10, padx=10)


        entProjectID = Entry(frame1, textvariable=txtProjectID, width=30)
        entProjectID.grid(row=1, column=1, pady=10, padx=10)

        entInsuranceTypeID = Entry(frame1, textvariable=txtInsuranceTypeID, width=30)
        entInsuranceTypeID.grid(row=2, column=1, pady=10, padx=10)

        entInsuranceValue = Entry(frame1, textvariable=txtInsuranceValue, width=30)
        entInsuranceValue.grid(row=3, column=1, pady=10, padx=10)

        entDateOfIssuing = Entry(frame1, textvariable=txtDateOfIssuing, width=30)
        entDateOfIssuing.grid(row=4, column=1, pady=10, padx=10)

        entNumberOfInstallments = Entry(frame1, textvariable=txtNumberOfInatallments, width=30)
        entNumberOfInstallments.grid(row=5, column=1, pady=10, padx=10)

        entPersonID = Entry(frame1, textvariable=txtPerosonID, width=30)
        entPersonID.grid(row=6, column=1, pady=10, padx=10)

        btnBack = Button(frame1, text='Back' , width=10, command=BackMethod)
        btnBack.grid(row = 7, column=1, pady=10, padx=10, sticky='nw')

        btnSet = Button(frame1, text='Set', width=10, command=SetNewInsurance)
        btnSet.grid(row=7, column=1, pady=10, padx=10, sticky='ne')

        frame1.place(x=0, y=0)


        image2 = PhotoImage(file='149.png')
        frame2 = Frame(newInsurance)

        picbtn2 = Label(master=frame2, image=image2)

        picbtn2.grid(row=0, column=0, padx=15, ipadx=15)

        frame2.place(x=130, y=370)


        newInsurance.mainloop()
