from tkinter import *
from UILayer import *
from tkinter import messagebox as msg
from DataTransmissionLayer import *

LoginForm = Tk()
LoginForm.title("Login Form")
LoginForm.geometry('400x450')
LoginForm.resizable(0,0)

txtUserName = StringVar()
txtPassword = StringVar()

def CheckingValidation(*args):
    if(len(txtUserName.get()) > 10):
        txtUserName.set(txtUserName.get()[:10])

def CheckingAuthentication():
    if txtUserName.get()== 'admin' and txtPassword.get() == '123':
        mainForm = MainFormClass()
        LoginForm.destroy()
        mainForm.LoadMainForm()
    else:
        msg.showerror('Error','The user Name or Password is Invalid')


def ResetFormMethod():
    for widget in LoginForm.winfo_children():
        if isinstance(widget, Entry):
            widget.delete(0,END)

LblUsername = Label(LoginForm, text= 'User Name:', font=('calibary',13))
LblUsername.grid(row=0 , column=0, padx=15, pady=15)

LblPassword = Label(LoginForm, text= 'Password:',font=('calibary',13))
LblPassword.grid(row=1 , column=0, padx=15, pady=15)


entUserName = Entry(LoginForm , width= 25, textvariable=txtUserName, justify='center')
entUserName.grid(row= 0 , column= 1, padx=15, pady= 15 )

entPassword = Entry(LoginForm, width= 25, show = '*', textvariable=txtPassword, justify='center')
entPassword.grid(row= 1 , column= 1, padx=15, pady= 15)

btnReset = Button(LoginForm, text= 'Reset', width=10, command= ResetFormMethod)
btnReset.grid(row=2, column=1, padx= 15, pady=15, sticky='wn')

btnLogin = Button(LoginForm, text= 'Login', width=10, command= CheckingAuthentication)
btnLogin.grid(row=2, column=1, padx= 15, pady=15, sticky='en')


image = PhotoImage(file= 'login.png')

ImageLable = Label(LoginForm, image= image )
ImageLable.grid(row=3, column=1, padx= 5, ipadx=5)

txtUserName.trace('w', CheckingValidation)


LoginForm.mainloop()