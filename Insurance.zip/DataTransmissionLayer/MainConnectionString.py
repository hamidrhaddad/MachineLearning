class NewConnectionString:
    def MainNewConnctionString(self):
        import pyodbc

        ConnectionString = "Driver={sql server Native Client 11.0};"\
                            "server=localhost;"\
                            "database=InsuranceIWPCOManagementSystem;"\
                            "uid=sa;pwd=Parsa4147"
        sqlConnection = pyodbc.connect(ConnectionString)
        return sqlConnection



